import flask
import time
from . import database


admin_blueprint = flask.Blueprint('admin',__name__,url_prefix='/admin')


def admin_access_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if flask.g.admin_session_token is None:
            flask.abort(403,description="Admin access is required!")
        return flask_view(**kwargs)

    return wrapped_view





@admin_blueprint.route('/login',methods=['POST'])
def admin_login():
    data = flask.request.json

    admin_id = data.get('admin_id',None)
    password = data.get('password',None)

    if e_mail is None:
        flask.abort(400,description = f"Admin ID is Required!")
    elif password is None:
        flask.abort(400,description = f"Password is Required!")



    connection = database.get_connection()
    cursor = connection.cursor(dictionary=True)

    cursor.execute(''' SELECT ID_NUMBER as ADMIN_ID,PASSWORD from ADMIN WHERE ID_NUMBER = %s ;''',
            (e_mail, ) )

    credentials = cursor.fetchone() 

    if not credentials:
        flask.abort(400, description = f"ADMIN ID Is INVALID!"  )

    database_password = credentials['PASSWORD']

    if password == database_password :
        cursor.execute(''' DELETE FROM  ADMIN_SESSIONS WHERE ADMIN_ID = %s ;''',(admin_id,) ) 
        session_token = uuid.uuid4().hex # get uuid as it's hex
        session_expire_time = datetime.datetime.now() + datetime.timedelta(minutes=10)
        cursor.execute('''
        INSERT INTO USER_SESSIONS (ADMIN_ID,EXPIRES,TOKEN)
        VALUES ( %s,%s,%s ) ;''' , 
        (admin_id,session_expire_time,session_token) )

        flask.session['admin_session_token'] = str(session_token)

    return { "success":"authentication" }



@admin_blueprint.before_request
def load_admin_session():

    admin_session_token = flask.session.get('admin_session_token',None)

    if admin_session_token is None:
        flask.g.admin_session_token = None
    else:
        connection = database.get_connection()
        cursor = connection.cursor(dictionary=True)

        cursor.execute(''' SELECT ADMIN_ID,EXPIRES FROM ADMIN_SESSIONS where TOKEN = %s ; ''',
                (admin_session_token,) )
        token_data = cursor.fetchone()

        if token_data:
            admin_id = token_data['ADMIN_ID']
            expiry_time = token_data['EXPIRES']

            now = datetime.datetime.now()

            if expiry_time > now:
                expiry_time = now + datetime.timedelta(minutes=10)
                cursor.execute(''' UPDATE ADMIN_ID SET  EXPIRES = %s WHERE TOKEN = %s ;''',
                        ( expiry_time , admin_session_token ) )

                flask.g.admin_session_token = admin_session_token
                flask.g.admin_id = admin_id
            else:

                cursor.execute(''' DELETE FROM ADMIN_SESSIONS WHERE TOKEN = %s ;''',
                        (  admin_session_token , ) )

                flask.g.admin_session_token = None
                flask.session.clear()

        else:
            flask.session.clear()
            flask.g.admin_session_token = None


@admin_blueprint.route('/modify_item/<int:product_id>',methods=['POST'])
@admin_access_required
def update_product_attributes(product_id:int):

    connection = database.get_connection()
    connection.start_transaction(isolation_level='SERIALIZABLE')
    cursor = connection.cursor(dictionary=True)

    cursor.execute(''' SELECT * FROM PRODUCT where ID_NUMBER = %s FOR UPDATE ; ''',
            ( product_id,) 
            )
    time.sleep(4)

    json_data = flask.request.json


    new_price = float(json_data['price'])
    new_discount = int(json_data['discount'])
    cursor.execute(
            '''UPDATE PRODUCT SET DISCOUNT = %s,PRICE = %s where ID_NUMBER =%s;'''
            , ( new_discount,new_price,product_id ) )

    connection.commit()

    return {"status":"success"}


@admin_blueprint.route('/update_inventory/<int:product_id>',methods=['POST'])
@admin_access_required
def update_product_inventory(product_id:int):

    connection = database.get_connection()
    connection.start_transaction(isolation_level='SERIALIZABLE')
    cursor = connection.cursor(dictionary=True)

    cursor.execute(''' SELECT QUANTITY FROM INVENTORY where ID_NUMBER = %s FOR UPDATE ; ''',
            ( product_id,) 
            )
    time.sleep(4)

    json_data = flask.request.json


    new_quantity = int(json_data['quantity'])
    cursor.execute(
            '''UPDATE INVENTORY SET QUANTITY = %s where ID_NUMBER =%s;'''
            , ( new_quantity,product_id ) )

    connection.commit()

    return {"status":"success"}
