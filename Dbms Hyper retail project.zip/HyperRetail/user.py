from . import auth
import time

from . import database
import flask


blueprint = flask.Blueprint('user',__name__,url_prefix='/user')

@blueprint.route('/cart',methods=['POST'])
@auth.login_required
def change_cart():
    '''Route That Changes contents
    Add items,change quantity of items,Delete items'''

    customer_id = flask.g.customer_id

    connection = database.get_connection()
    cursor = connection.cursor(dictionary=True)

    request_data = flask.request.json

    operation = request_data['op']

    product_id = int( request_data["product"] )

    cursor.execute(''' SELECT p.ID_NUMBER , c.QUANTITY from CARTS c,PRODUCT p
                    where c.CUSTOMER_ID = %s and c.PRODUCT_ID = %s and c.PRODUCT_ID = p.ID_NUMBER
                    for UPDATE
            ;''',
            ( customer_id,product_id ) )

    product_list = cursor.fetchone()

    if operation == "add":
        if product_list:
            quantity = product_list['QUANTITY']+1
            cursor.execute(''' UPDATE CARTS SET QUANTITY = %s
            where
            CUSTOMER_ID = %s and PRODUCT_ID = %s ;''',
            ( quantity, customer_id, product_id) ) 
        else:
            quantity = 1
            #fetch details of product that is to be added
            cursor.execute(''' SELECT ID_NUMBER,PRICE,DISCOUNT,AVAILABILITY FROM 
            PRODUCT WHERE ID_NUMBER = %s ; ''',(product_id,))
            product_details = cursor.fetchone()

            cursor.execute(''' INSERT INTO CARTS 
            (CUSTOMER_ID,PRODUCT_ID,PRICE,DISCOUNT,QUANTITY)
            VALUES (%s,%s,%s,%s,%s) ;''', 
            ( customer_id,
                product_id ,
                product_details['PRICE'],
                product_details['DISCOUNT'],
                quantity,) )

    elif operation == 'subtract':
        quantity = int( request_data['quantity'] ) -1 
        if quantity > 0:
            cursor.execute(''' UPDATE CARTS SET QUANTITY = %s
            where
            CUSTOMER_ID = %s and PRODUCT_ID = %s ;''',
            ( quantity, customer_id, product_id) ) 
        elif quantity == 0:
            cursor.execute(''' DELETE FROM CARTS WHERE 
            CUSTOMER_ID = %s and PRODUCT_ID = %s ;''',
            (customer_id,product_id) )

    return {"status":"success"}


@blueprint.route('/cart/view',methods=['GET'])
@auth.login_required
def view_user_cart():
    ''' Returns all the items in the cart of a user 
    Along with their details '''
    customer_id = flask.g.customer_id

    connection = database.get_connection()
    cursor = connection.cursor(dictionary=True)
    cursor.execute('''
      select B.ID_NUMBER as 'PRODUCT_ID',
      B.NAME as 'PRODUCT_NAME',
      A.QUANTITY as 'QUANTITY',
      A.PRICE AS 'ITEM_PRICE',
      A.DISCOUNT,
      A.QUANTITY*(A.PRICE - (A.DISCOUNT*A.PRICE)/100) as 'NET_PRICE'
 FROM CARTS A ,CUSTOMER C, PRODUCT B 
     where A.CUSTOMER_ID = %s and C.ID_NUMBER = A.CUSTOMER_ID 
     and B.ID_NUMBER=A.PRODUCT_ID ;''',
     (customer_id,) )
    result = cursor.fetchall()

    return result

@blueprint.route('/orders/view',methods=['GET'])
@auth.login_required
def get_orders():
    ''' Get Previous orders of a customer as a list '''
    customer_id = flask.g.customer_id

    connection = database.get_connection()
    cursor = connection.cursor(dictionary=True)
    cursor.execute('''
    select A.ID_NUMBER as 'ORDER_ID',
     A.DATE as 'ORDER_DATE',
    sum( A.QUANTITY ) as 'NO_OF_ITEMS', 
    sum(A.QUANTITY * (A.PRICE - (A.DISCOUNT*A.PRICE)/100)) as 'NET_PRICE' FROM ORDERS A ,CUSTOMER C, PRODUCT B 
    where C.ID_NUMBER = %s 
   and C.ID_NUMBER = A.CUSTOMER_ID 
   and B.ID_NUMBER=A.PRODUCT_ID group by A.CUSTOMER_ID,A.DATE,A.ID_NUMBER
   order by A.DATE DESC ;
    ''',
    (customer_id,) )

    result = cursor.fetchall()
    return result

@blueprint.route('/place_order',methods=['GET'])
@auth.login_required
def place_order():

    customer_id = flask.g.customer_id

    connection = database.get_connection()
    cursor = connection.cursor(dictionary=True)

    cursor.execute(
            ''' CREATE TEMPORARY TABLE USER_ORDER
            select PRODUCT_ID,QUANTITY FROM CARTS WHERE CUSTOMER_ID = %s ; '''
            ,(flask.g.customer_id,) )

    cursor.execute(
    '''
    Select count(PRODUCT_ID) from INVENTORY where PRODUCT_ID IN
    (SELECT PRODUCT_ID FROM USER_ORDER) FOR UPDATE ; ''')
    _ = cursor.fetchone()

    cursor.execute(''' select count(*) as 'count' from 
    USER_ORDER ; ''' )

    desired_order = cursor.fetchone()['count']

    cursor.execute(''' SELECT count(U.PRODUCT_ID) as 'count' from USER_ORDER U, PRODUCT P,
        INVENTORY I  where I.PRODUCT_ID = U.PRODUCT_ID and P.ID_NUMBER = U.PRODUCT_ID 
        and (I.QUANTITY - U.QUANTITY)>0 FOR UPDATE; ''')
    available_order = cursor.fetchone()['count']


    if available_order == desired_order:
        cursor.execute(
        '''
        update INVENTORY c,USER_ORDER p,PRODUCT P 
        set c.QUANTITY = c.QUANTITY - p.QUANTITY 
        where p.PRODUCT_ID = c.PRODUCT_ID and P.ID_NUMBER = c.PRODUCT_ID ;
       ''' 
       )
        cursor.execute(''' SELECT max(ID_NUMBER) as 'max' from ORDERS for UPDATE ;''')
        order_id = cursor.fetchone()['max'] + 1

        cursor.execute(''' INSERT INTO 
        ORDERS
        (CUSTOMER_ID,PRODUCT_ID,QUANTITY,PRICE,DISCOUNT,ID_NUMBER)
        select %s, c.ID_NUMBER,u.QUANTITY,c.PRICE,c.DISCOUNT,%s from USER_ORDER u,PRODUCT c 
        where u.PRODUCT_ID = c.ID_NUMBER;'''
        ,
        ( customer_id,order_id) )

        time.sleep(5)

        cursor.execute(''' DELETE FROM CARTS WHERE CUSTOMER_ID = %s ;''',(customer_id,) )

        return { 'status':'success' }
    else:

        connection.rollback()
        flask.abort(400,description="Items In Your Cart are not available right now" )





@blueprint.route('/orders/view/<int:order_id>',methods=['GET'])
@auth.login_required
def get_order_invoice(order_id):
    '''Get invoice of a particular order'''
    customer_id = flask.g.customer_id

    connection = database.get_connection()
    cursor = connection.cursor(dictionary=True)
    cursor.execute('''
    select B.NAME as 'PRODUCT_NAME', 
           A.QUANTITY as 'QUANTITY',
           A.DATE as 'ORDER_DATE',
           A.PRICE AS 'ITEM_PRICE',
           A.DISCOUNT,
           A.PRICE*A.QUANTITY as 'GROSS',
          A.QUANTITY * (A.PRICE - (A.DISCOUNT*A.PRICE)/100) as 'NET_PRICE' 
      FROM ORDERS A ,CUSTOMER C, PRODUCT B where 
         A.ID_NUMBER = %s and A.CUSTOMER_ID = %s 
        and C.ID_NUMBER = A.CUSTOMER_ID 
        and B.ID_NUMBER = A.PRODUCT_ID ;
    ''',
    (order_id,customer_id,) )

    result = cursor.fetchall()

    order_total = sum( [ x['GROSS'] for x in result ] )
    net_price = sum( [ x['NET_PRICE'] for x in result ] )

    return { 'TOTAL' : order_total , 'NET_PRICE' : net_price , 'INVOICE' : result } 
