import flask
import functools
import uuid
import json
import datetime


from . import database

bp = flask.Blueprint('auth',__name__,url_prefix='/auth')

def login_required(flask_view):
    @functools.wraps(flask_view)
    def wrapped_view(**kwargs):
        if flask.g.session_token is None:
            flask.abort(403,description="You need to be logged in!")

        return flask_view(**kwargs)

    return wrapped_view


@bp.route('/login',methods=['POST'])
def login():
    data = flask.request.json
    e_mail = data.get('e_mail',None)
    password = data.get('password',None)

    if e_mail is None:
        flask.abort(400,description = f"E-Mail is Required!")
    elif password is None:
        flask.abort(400,description = f"Password is Required!")



    connection = database.get_connection()
    cursor = connection.cursor(dictionary=True)

    cursor.execute(''' SELECT ID_NUMBER as CUSTOMER_ID,PASSWORD from CUSTOMER WHERE E_MAIL = %s ;''',
            (e_mail, ) )

    credentials = cursor.fetchone() 

    if not credentials:
        flask.abort(400, description = f"{e_mail} is not registered!"  )

    customer_id = credentials['CUSTOMER_ID']
    database_password = credentials['PASSWORD']

    if password == database_password:
        cursor.execute(''' DELETE FROM  USER_SESSIONS WHERE CUSTOMER_ID = %s ;''',(customer_id,) ) 
        session_token = uuid.uuid4().hex # get uuid as it's hex
        session_expire_time = datetime.datetime.now() + datetime.timedelta(minutes=30)
        cursor.execute('''
        INSERT INTO USER_SESSIONS (CUSTOMER_ID,EXPIRES,TOKEN)
        VALUES ( %s,%s,%s ) ;''' , 
        (customer_id,session_expire_time,session_token) )

        flask.session['session_token'] = str(session_token)

    return { "success":"authentication" }

@bp.before_app_request
def load_user_session():
    ''' Check if the stored session is expired or not.
    If the stored session is not expired then token's expiry is
    moved forward by 30 minutes.
    Customer_id and session_token is set on flask's g object
    '''
    session_token = flask.session.get('session_token',None)

    if session_token is None:
        flask.g.session_token = None
    else:
        connection = database.get_connection()
        cursor = connection.cursor(dictionary=True)

        cursor.execute(''' SELECT CUSTOMER_ID,EXPIRES FROM USER_SESSIONS where TOKEN = %s ; ''',
                (session_token,) )
        token_data = cursor.fetchone()

        if token_data:
            customer_id = token_data['CUSTOMER_ID']
            expiry_time = token_data['EXPIRES']

            now = datetime.datetime.now()

            if expiry_time > now:
                expiry_time = now + datetime.timedelta(minutes=30)
                cursor.execute(''' UPDATE USER_SESSIONS SET  EXPIRES = %s WHERE TOKEN = %s ;''',
                        ( expiry_time , session_token ) )

                flask.g.session_token = session_token
                flask.g.customer_id = customer_id

            else:
                cursor.execute(''' DELETE FROM USER_SESSIONS WHERE TOKEN = %s ;''',
                        (  session_token , ) )

                flask.g.session_token = None
                flask.session.clear()

        else:
            flask.session.clear()
            flask.g.session_token = None



@bp.route('/signup',methods=["POST"])
def signup():
    session_token = flask.g.session_token

    connection = database.get_connection()
    cursor = connection.cursor(dictionary=True)


    request_data = flask.request.json
    
    e_mail = request_data['e_mail']
    password = request_data['password']
    address = request_data['address']
    user_name = request_data['user_name']
    

    cursor.execute(''' SELECT * FROM CUSTOMER WHERE E_MAIL = %s FOR SHARE ;''' ,
            (e_mail,) ) 
    existing = cursor.fetchone()
    if existing:
        flask.abort(400,description="There exists a user with this!" )
    else:
        cursor.execute(''' INSERT INTO CUSTOMER 
        (NAME,E_MAIL,ADDRESS,PASSWORD) 
        VALUES (%s,%s,%s,%s);''',
        ( user_name,e_mail,address,password ) )

    flask.session.clear()
    return { "status" : "signed up!" }



@bp.route('/logout',methods=["POST"])
@login_required
def logout():
    session_token = flask.g.session_token

    connection = database.get_connection()
    cursor = connection.cursor(dictionary=True)

    cursor.execute(''' DELETE FROM USER_SESSIONS WHERE TOKEN = %s ;''',
            (  session_token , ) )
    flask.session.clear()

    return { "status" : "logged out" }
