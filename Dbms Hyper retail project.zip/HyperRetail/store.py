from . import database
import flask
import datetime
from . import auth

blueprint = flask.Blueprint('store',__name__,url_prefix='/store')

@blueprint.route('/search',methods=['POST'])
def store_search():

    sort_criteria_map = { 
            'DATE_ADDED' : 'ID_NUMBER',
            'NAME' : 'NAME',
            'PRICE' : 'PRICE'
            }

    search_data = flask.request.json


    search_string = search_data['QUERY']


    if search_string == '':
        search_string = '%%'
    else:
        search_string = f'%{search_string}%'


    sort_criteria = search_data['CRITERIA'] 
    
    page_size = int(search_data['PAGE_SIZE'])
    page_number = int(search_data['PAGE_NUMBER'])

    sort_by = sort_criteria_map[sort_criteria]


    connection = database.get_connection()
    cursor = connection.cursor(dictionary=True)


    offset = (page_number-1)*page_size


    query_base = '''
    SELECT 
    P.ID_NUMBER,
    P.NAME,
    P.PRICE,
    P.DISCOUNT,
    C.CATEGORY_NAME

    FROM PRODUCT P, CATEGORY C 
    WHERE P.CATEGORY_ID = C.CATEGORY_ID
    and 
    P.NAME like %s ''' 

    query_with_page = query_base + '''ORDER BY P.{criteria}
    LIMIT %s
    OFFSET %s

    FOR SHARE SKIP LOCKED
    '''.format(criteria = sort_by) 


    count_query = ''' SELECT COUNT(*) as 'count' FROM ( {} ) as t ; '''.format(query_base) 

    cursor.execute(count_query, (search_string,) )
    query_count = cursor.fetchone()  
    query_count = query_count['count'] // page_size
    query_count+=1


    cursor.execute( query_with_page,
        ( search_string, 
            page_size,
            offset ) )

    search_result = cursor.fetchall()

    result = { 'count':query_count, 'result':search_result}  

    return result

@blueprint.route('/item/<int:product_id>',methods=['GET'])
def product_info(product_id:int)->flask.Response:
    '''Returns information about a product'''

    connection = database.get_connection()
    cursor = connection.cursor(dictionary=True)

    cursor.execute('''
        SELECT 
            P.ID_NUMBER as 'PRODUCT_ID',
            P.NAME,
            P.PRICE,
            C.CATEGORY_NAME as 'CATEGORY',
            P.AVAILABILITY,
            P.DISCOUNT
            from PRODUCT P, CATEGORY C
            where P.ID_NUMBER = %s
            and C.CATEGORY_ID = P.CATEGORY_ID
            FOR SHARE
            ; '''
            , (product_id,) )

    product_info = cursor.fetchone()

    return product_info

@blueprint.route('/item/<int:product_id>/reviews',methods=['GET'])
def product_reviews(product_id:int)->flask.Response:
    '''Returns product's reviews! '''

    connection = database.get_connection()
    cursor = connection.cursor(dictionary=True)

    cursor.execute('''
        SELECT 
            P.ID_NUMBER as 'PRODUCT_ID',
            C.NAME as 'USER_NAME',
            R.DATE as 'REVIEW_DATE',
            R.RATING,
            R.REVIEW,
            P.DISCOUNT from PRODUCT P,REVIEWS R, CUSTOMER C
            where P.ID_NUMBER = %s
            and R.PRODUCT_ID = P.ID_NUMBER
            and R.CUSTOMER_ID = C.ID_NUMBER
            order by R.DATE DESC
            FOR SHARE SKIP LOCKED
            ; '''
            , (product_id,) )

    product_reviews = cursor.fetchall()

    return product_reviews

@blueprint.route('/item/<int:product_id>/qna',methods=['GET'])
def product_qna(product_id:int)->flask.Response:
    '''Returns product's Questions And Answers! '''

    connection = database.get_connection()
    cursor = connection.cursor(dictionary=True)

    cursor.execute('''
        SELECT 
            P.ID_NUMBER as 'PRODUCT_ID',
            C.NAME as 'USER_NAME',
            Q.DATE as 'QUESTION_DATE',
            Q.QUESTION,
            Q.ANSWER
            from PRODUCT P,QnA Q, CUSTOMER C 
            where P.ID_NUMBER = %s
            and Q.PRODUCT_ID = P.ID_NUMBER
            and Q.CUSTOMER_ID = C.ID_NUMBER
            order by Q.DATE DESC
            FOR SHARE SKIP LOCKED
            ; '''
            , (product_id,) )

    product_qna = cursor.fetchall()
    return product_qna


@blueprint.route('/item/<int:product_id>/write',methods=['POST'])
@auth.login_required
def write_review(product_id):
    json_data = flask.request.json

    review_content = json_data['review']

    customer_id = flask.g.customer_id
    rating = json_data.get('rating')
    if not rating:
        rating = int(3)
    else:
        rating = int(rating)


    connection = database.get_connection()
    cursor = connection.cursor(dictionary=True)

    cursor.execute(''' 
    INSERT INTO REVIEWS 
    (CUSTOMER_ID,PRODUCT_ID,REVIEW,RATING,DATE)
    VALUES
    (%s,%s,%s,%s,%s);
    ''',( customer_id , product_id , review_content, 
        rating,
        datetime.datetime.now() ) )

    return {"status":"success"}

@blueprint.route('/item/<int:product_id>/ask',methods=['POST'])
@auth.login_required
def ask_a_question(product_id):
    json_data = flask.request.json

    question = json_data['question']

    customer_id = flask.g.customer_id

    connection = database.get_connection()
    cursor = connection.cursor(dictionary=True)

    cursor.execute(''' 
    INSERT INTO QnA 
    (CUSTOMER_ID,PRODUCT_ID,QUESTION,DATE)
    VALUES
    (%s,%s,%s,%s);
    ''',( customer_id , product_id , question, 
        datetime.datetime.now() ) )

    return {"status":"success"}
