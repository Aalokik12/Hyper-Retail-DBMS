import mysql.connector as connector
import flask


def get_connection() -> connector.MySQLConnection :
    if 'database' not in flask.g:

        connection = connector.connect(user='app',
                password='apppass',
                host='127.0.0.1',
                database=flask.current_app.config['DATABASE'])

        flask.g.database = connection

    return flask.g.database

def close_db(flask_data):
    ''' Closes and commits the changes to database '''
    database = flask.g.get('database',None)

    if database is not None:
        database.commit()
        database.close()

def init_db(application):
    application.teardown_appcontext(close_db)
