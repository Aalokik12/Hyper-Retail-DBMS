<script >
import { RouterLink, RouterView } from 'vue-router'

import { state } from './state';

export default {

  data() {
    return {
      state,
    }
  },
  mounted() {
    let auth_status = localStorage.getItem('auth');
    if (auth_status === 'true') {
      state.auth = true;
    }
    else {
      state.auth = false;
    }
  },
  methods: {
    logout() {

      fetch(`/api/auth/logout`, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "content-type": "application/json",
        },
        credentials: "same-origin",
      })
        .then((response) => response.json())
        .then((data) => {
          state.auth = false;
          localStorage.setItem('auth', 'false');
        });
    }
  }

}

</script>

<template>
  <v-app>
  <v-main>
    <RouterView />
  </v-main>
    <v-app-bar :elevation="2" rounded
    
    :title="'Hyper Retail : ' + state.title"
    >
    </v-app-bar>
    
    <v-bottom-navigation>
      <v-btn value="search" to="/">
        <v-icon>mdi-magnify</v-icon>
        Search
      </v-btn>
      <v-btn value="orders" to="/user/orders/view">
        <v-icon>mdi-history</v-icon>
        Previous Orders
      </v-btn>

      <v-btn value="logout" v-if="this.state.auth" @click="logout">
        <v-icon>mdi-logout</v-icon>
        Logout
      </v-btn>

      <v-btn value="login" v-else to="/user/login">
        <v-icon>mdi-login</v-icon>
        Login
      </v-btn>

      <v-btn value="cart" :to="`/user/cart`">
        <v-icon>mdi-cart</v-icon>
        Cart
      </v-btn>
    </v-bottom-navigation>
  </v-app>
</template>

<style scoped></style>
