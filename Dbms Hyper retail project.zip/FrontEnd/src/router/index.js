import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import ProductView from '../views/ProductView.vue'
import UserCart from '../views/UserCart.vue'
import UserLogin from '../views/UserLogin.vue'
import OrderInvoice from '../views/OrderInvoice.vue'
import PreviousOrders from '../views/PreviousOrders.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView
    },
    {
      path: '/item/:id',
      name: 'product',
      component: ProductView
    },
    {
      path: '/user/cart',
      name: 'cart',
      component: UserCart
    },
    {
      path: '/user/login',
      name: 'user_login',
      component: UserLogin
    },
    {
      path: '/user/orders/view',
      name: 'user_orders',
      component: PreviousOrders
    },
    {
      path: '/user/orders/view/:id',
      name: 'order_invoice',
      component: OrderInvoice
    },

,


  ]
})

export default router
