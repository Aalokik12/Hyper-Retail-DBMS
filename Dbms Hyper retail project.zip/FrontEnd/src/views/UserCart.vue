<script>
import { state } from '../state'

export default {

    data() {
        return {
            order_id: this.$route.params.id,
            items: [],
            price: '',
            total: '',
            snackbar: false,
            state
        }
    },
    mounted() {
        state.title = 'Your Cart'
        if (!state.auth) {
            this.snackbar = true;

        }
        else {
            this.fetch_cart();
        }
    },
    methods: {
        fetch_cart() {

            fetch(`/api/user/cart/view`, {
                headers: {
                    Accept: "application/json",
                    "content-type": "application/json",
                },
                credentials: "same-origin",
            })
                .then((response) => response.json())
                .then((data) => {
                    this.items = data;

                    this.total = 0;
                    this.items.map((e) => {
                        this.total += Number(e.NET_PRICE);
                    })
                    console.log(data);
                });
        },
        subtract_item(item_id, quantity) {

            let payload = {
                'op': 'subtract',
                'product': `${item_id}`,
                'quantity': `${quantity}`
            }
            fetch(`/api/user/cart`, {
                method: 'POST',
                headers: {
                    Accept: "application/json",
                    "content-type": "application/json",
                },
                body: JSON.stringify(payload),
                credentials: "same-origin",
            })
                .then((response) => response.json())
                .then((data) => {

                    this.fetch_cart();
                });
        },
        add_item(item_id) {

            let payload = {
                'op': 'add',
                'product': `${item_id}`
            }
            fetch(`/api/user/cart`, {
                method: 'POST',
                headers: {
                    Accept: "application/json",
                    "content-type": "application/json",
                },
                body: JSON.stringify(payload),
                credentials: "same-origin",
            })
                .then((response) => response.json())
                .then((data) => {
                    this.fetch_cart();
                });
        },
        place_order() {
            fetch(`/api/user/place_order`, {
                headers: {
                    Accept: "application/json",
                    "content-type": "application/json",
                },
                credentials: "same-origin",
            })
                .then((response) => response.json())
                .then((data) => {
                    console.log(data);
                    this.fetch_cart();
                });
        },
        navigate_back() {
            this.snackbar = false;
            this.$router.replace({ path: '/' })
        }
    }
}
</script>

<template>
    <v-snackbar v-model="snackbar">
        You Must Be Logged In!
        <template v-slot:actions>
            <v-btn color="pink" variant="text" @click="navigate_back">
                Close
            </v-btn>
        </template>
    </v-snackbar>

    <v-container>
        <v-row justify="center">
            <v-col cols="8">

                <v-table>
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Price</th>
                            <th>Discount</th>
                            <th>Quantity</th>
                            <th>Net Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="item in this.items">
                            <td>{{ item['PRODUCT_NAME'] }}</td>
                            <td>{{ item['ITEM_PRICE'] }}</td>
                            <td>{{ item['DISCOUNT'] }}</td>
                            <td>
                                <v-btn icon="mdi-minus" size="x-small"
                                    @click="subtract_item(item.PRODUCT_ID, item.QUANTITY)"></v-btn>
                                {{ item['QUANTITY'] }}
                                <v-btn icon="mdi-plus" size="x-small" @click="add_item(item.PRODUCT_ID)"></v-btn>
                            </td>
                            <td>{{ item['NET_PRICE'] }}</td>
                        </tr>
                    </tbody>
                </v-table>

                <v-row>
                    Total : {{ this.total }}
                </v-row>
                <v-row>
                    <v-btn @click="this.place_order">Place Order!</v-btn>
                </v-row>
            </v-col>
        </v-row>
    </v-container>
</template>