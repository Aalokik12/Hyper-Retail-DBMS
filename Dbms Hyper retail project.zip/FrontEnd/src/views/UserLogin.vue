<script>


import { state } from '../state.js';
export default {

    data() {
        return {
            loginstate:true,
            user_name:'',
            e_mail: '',
            password: '',
            address: '',
            state,

        }
    },
    methods: {
        loginh() {

            let payload = {
                'e_mail': this.e_mail,
                'password': this.password
            }

            fetch(`/api/auth/login`, {
                method: "POST",
                headers: {
                    Accept: "application/json",
                    "content-type": "application/json",
                },
                body: JSON.stringify(payload),
                credentials: "same-origin",
            })
                .then((response) => response.json())
                .then((data) => {
                    state.auth = true;
                    localStorage.setItem('auth', 'true');
                });
        },
        signup() {
            let payload = {
                'e_mail': this.e_mail,
                'password': this.password,
                'user_name': this.user_name,
                'address': this.address
            }

            fetch(`/api/auth/signup`, {
                method: "POST",
                headers: {
                    Accept: "application/json",
                    "content-type": "application/json",
                },
                body: JSON.stringify(payload),
                credentials: "same-origin",
            })
                .then((response) => response.json())
                .then((data) => {
                    state.auth = false;
                    localStorage.setItem('auth', 'false');
                });
        }

    }
}



</script>

<template>
    <main>
        <v-container>
            <v-row justify="center">
                <v-switch v-model="this.loginstate" :label="this.loginstate ? 'Login' : 'Signup' "></v-switch>
            </v-row>
            <v-form v-if="this.loginstate" @submit.prevent="loginh">
                <v-container>
                    <v-row justify="center">
                        <v-col cols="8">
                            <v-text-field v-model="this.e_mail" label="E-mail"></v-text-field>
                            <v-text-field v-model="this.password" type="password" label="Password"></v-text-field>
                            <v-btn type="submit">Submit</v-btn>
                        </v-col>
                    </v-row>
                </v-container>
            </v-form>
            <v-form v-else @submit.prevent="signup" >
                <v-container>
                    <v-row justify="center">
                        <v-col cols="8">
                            <v-text-field v-model="this.e_mail" label="E-mail" required></v-text-field>
                            <v-text-field v-model="this.user_name" label="NAME" required></v-text-field>
                            <v-text-field v-model="this.password" type="password" label="Password" required></v-text-field>
                            <v-textarea v-model="this.address" label="Address" required></v-textarea>
                            <v-btn type="submit">Signup</v-btn>
                        </v-col>
                    </v-row>
                </v-container>
            </v-form>
        </v-container>
    </main>
</template>