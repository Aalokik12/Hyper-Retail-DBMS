<script>
import { state } from '../state'

export default {

    data() {
        return {
            orders: [],
            snackbar: false,
            state
        }
    },
    mounted() {

        state.title = 'Your Orders'
        if (!state.auth) {
            this.snackbar = true;
        }
        else {
            fetch(`/api/user/orders/view`, {
                headers: {
                    Accept: "application/json",
                    "content-type": "application/json",
                },
                credentials: "same-origin",
            })
                .then((response) => response.json())
                .then((data) => {
                    this.orders = data;
                    console.log(this.orders);
                });
        }
    }
}
</script>

<template>
    <v-main>
        <v-snackbar v-model="snackbar">
            You Must Be Logged In!
            <template v-slot:actions>
                <v-btn color="pink" variant="text" @click="snackbar = false">
                    Close
                </v-btn>
            </template>
        </v-snackbar>
        <v-container>
            <v-row justify="center">
                <v-col cols="10">
                    <v-table>
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Time Placed</th>
                                <th>Items Ordered</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="order in this.orders">
                                <td><router-link
        
                                    :to='`/user/orders/view/${order.ORDER_ID}`'
                                    >{{ order['ORDER_ID'] }}</router-link></td>
                                <td>{{ order['ORDER_DATE'] }}</td>
                                <td>{{ order['NO_OF_ITEMS'] }}</td>
                                <td>{{ order['NET_PRICE'] }}</td>
                            </tr>
                        </tbody>
                    </v-table>
                </v-col>
            </v-row>
        </v-container>
    </v-main>
</template>