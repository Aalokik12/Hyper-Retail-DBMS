<script>
import { state } from '../state'

export default {

  data() {
    return {
      order_id:this.$route.params.id,
      items: [],
      price: '',
      total: '',
      snackbar: false,
      state
    }
  },
  mounted() {
    if (!state.auth) {
      this.snackbar = true;
    }
    else {
      fetch(`/api/user/orders/view/${this.order_id}`, {
        headers: {
          Accept: "application/json",
          "content-type": "application/json",
        },
        credentials: "same-origin",
      })
        .then((response) => response.json())
        .then((data) => {
          this.items = data.INVOICE;
          this.price = data.NET_PRICE;
          this.total = data.TOTAL;
        });
    }
  }
}
</script>

<template>
  <v-snackbar v-model="snackbar">
    You Must Be Logged In!

    <template v-slot:actions>
      <v-btn color="pink" variant="text" @click="snackbar = false">
        Close
      </v-btn>
    </template>
  </v-snackbar>

  <v-container>
    <v-row justify="center">
      <v-col cols="10">

        <v-row>
          <v-table>
            <thead>
              <tr>
                <th>Product Name</th>
                <th>Price</th>
                <th>Discount</th>
                <th>Quantity</th>
                <th>Net Price</th>
                <th>Gross</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="item in this.items">
                <td>{{ item['PRODUCT_NAME'] }}</td>
                <td>{{ item['ITEM_PRICE'] }}</td>
                <td>{{ item['DISCOUNT'] }}</td>
                <td>{{ item['QUANTITY'] }}</td>
                <td>{{ item['NET_PRICE'] }}</td>
                <td>{{ item['GROSS'] }}</td>
              </tr>
            </tbody>
          </v-table>
        </v-row>

        <v-row>
          Total : {{ this.total }}
        </v-row>
        <v-row>Net Price : {{ this.price }}</v-row>
      </v-col>
    </v-row>
  </v-container>
</template>