<script>

import { state } from '../state';

export default {
  data() {
    return {
      value: 0,
      searchList: [],
      searchValue: "",
      search_criteria: "NAME",
      page_size: 10,
      page_number: 1,
      total_count: 1,
      state
    };
  },
  mounted() {
    state.title='Search'
    this.search();
  },
  methods: {
    search() {
      let searchParam = this.searchValue;

      let payload = {
        CRITERIA: this.search_criteria,
        PAGE_SIZE: this.page_size,
        PAGE_NUMBER: this.page_number,
        QUERY: `${searchParam}`,
      };

      fetch(`/api/store/search`, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "content-type": "application/json",
        },
        body: JSON.stringify(payload),
        credentials: "same-origin",
      })
        .then((response) => response.json())
        .then((data) => {
          this.total_count = Number(data['count']);
          this.searchList = data['result'];
        });
    },
    add_to_cart(item_id) {
      let payload = {
        'op': 'add',
        'product': `${item_id}`
      }
      fetch(`/api/user/cart`, {
        method: 'POST',
        headers: {
          Accept: "application/json",
          "content-type": "application/json",
        },
        body: JSON.stringify(payload),
        credentials: "same-origin",
      })
        .then((response) => response.json())
        .then((data) => {
        });
    }
  },

  watch: {
    page_number(next, previous) {
      this.page_number = next;
      this.search();
    }
  }
};
</script>

<template>
        <v-form @submit.prevent="search">
          <v-container>
            <v-row justify="center" no-gutters>
              <v-col sm="6 " md="8" lg="5">
                <v-text-field label="Search" v-model="this.searchValue"></v-text-field>
              </v-col>
            </v-row>
            <v-row justify="center">
              <v-col sm="6" md="8" lg="5">
                <v-radio-group inline label="Sort By:" v-model="this.search_criteria">
                  <v-radio label="NAME" value="NAME"></v-radio>
                  <v-radio label="PRICE" value="PRICE"></v-radio>
                  <v-radio label="DATE ADDED" value="DATE_ADDED"></v-radio>
                </v-radio-group>
              </v-col>
            </v-row>
          </v-container>
        </v-form>
        <v-container>
          <v-row justify="center">
            <v-col cols="8">
              <v-table>
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Discount</th>
                    <th>Category</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="items in this.searchList">
                    <td>
                      <v-tooltip text="Add To Cart" location="start">
                        <template v-slot:activator="{ props }">
                          <v-btn size="x-small" class="ma-2" v-bind="props" icon="mdi-plus" @click="add_to_cart(items.ID_NUMBER)"></v-btn>
                        </template>
                      </v-tooltip>
                      <v-btn variant="text">
                      <router-link :to="`/item/${items.ID_NUMBER}`" class="text-black">
                        {{
                          items.NAME
                        }}
                        </router-link>
                      </v-btn>
                    </td>
                    <td>{{ items.PRICE }}</td>
                    <td>{{ items.DISCOUNT }}%</td>
                    <td>{{ items["CATEGORY_NAME"] }}</td>
                  </tr>
                </tbody>
              </v-table>
            </v-col>
          </v-row>
          <v-row justify="center">
            <v-pagination :length="this.total_count" v-model="this.page_number"></v-pagination>
          </v-row>
        </v-container>
</template>

<style>

a{
  text-decoration: none;
}

</style>
