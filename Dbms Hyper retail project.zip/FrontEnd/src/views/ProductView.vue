<script>

export default {
  data() {
    return {
      rating: 3,
      review: '',
      question: '',
      item_id: this.$route.params.id,
      review_dialog: false,
      qna_dialog: false,
      item_name: '',
      item_price: '',
      item_discount: '',
      item_category: '',
      item_reviews: [],
      item_qna: [],


    };
  },
  mounted() {
    this.fetchDetails();
    this.fetchReviews();
    this.fetchQnAs();
  },
  methods: {
    fetchDetails() {
      let searchParam = this.searchValue;

      fetch(`/api/store/item/${this.item_id}`, {
        headers: {
          Accept: "application/json",
          "content-type": "application/json",
        },
        credentials: "same-origin",
      })
        .then((response) => response.json())
        .then((data) => {

          console.log(data);
          this.item_price = data.PRICE;
          this.item_name = data.NAME;
          this.item_discount = data.DISCOUNT;
          this.item_category = data.CATEGORY;

        });
    },
    fetchReviews() {

      fetch(`/api/store/item/${this.item_id}/reviews`, {
        headers: {
          Accept: "application/json",
          "content-type": "application/json",
        },
        credentials: "same-origin",
      })
        .then((response) => response.json())
        .then((data) => {
          this.item_reviews = data;
        });

    },
    fetchQnAs() {
      fetch(`/api/store/item/${this.item_id}/qna`, {
        headers: {
          Accept: "application/json",
          "content-type": "application/json",
        },
        credentials: "same-origin",
      })
        .then((response) => response.json())
        .then((data) => {
          this.item_qna = data;
        });
    },
    write_review() {
      let payload = {
        'review': this.review,
        'rating': this.rating,
        'product_id': this.product_id
      }

      fetch(`/api/store/item/${this.item_id}/write`,
        {
          method: 'POST',
          credentials: 'same-origin',

          headers: {
            Accept: "application/json",
            "content-type": "application/json",
          },
          body: JSON.stringify(payload)
        })
        .then((response) => response.json())
        .then((data) => {
          console.log(data);
          this.review_dialog = false;
        });

    },
    ask_a_question() {

      let payload = {
        'question': this.question,
      }

      fetch(`/api/store/item/${this.item_id}/ask`,
        {
          method: 'POST',
          credentials: 'same-origin',

          headers: {
            Accept: "application/json",
            "content-type": "application/json",
          },
          body: JSON.stringify(payload)
        })
        .then((response) => response.json())
        .then((data) => {
          console.log(data);
          this.qna_dialog = false;
        });

    }
  },
};

</script>

<template>
  <v-dialog v-model="this.review_dialog">

    <v-card>
      <v-card-text>

        <v-textarea label="Review" v-model="this.review"></v-textarea>
        <v-rating v-model="this.rating" class="ma-2" density="compact"></v-rating>
      </v-card-text>
      <v-card-actions>
        <v-btn color="primary" block @click="this.write_review">Review!</v-btn>
      </v-card-actions>
    </v-card>

  </v-dialog>

  <v-dialog v-model="this.qna_dialog">
    <v-card>
      <v-card-title>Ask A Question</v-card-title>
      <v-card-text>

        <v-textarea label="Review" v-model="this.question"></v-textarea>
      </v-card-text>
      <v-card-actions>
        <v-btn color="primary" block @click="this.ask_a_question">Ask!</v-btn>
      </v-card-actions>
    </v-card>


  </v-dialog>

  <v-container>

    <v-row justify="center">

      <v-col cols="8">
        <v-row justify="center">Item : {{ this.item_name }}</v-row>
        <v-row justify="center">Price : {{ this.item_price }}</v-row>
        <v-row justify="center">Discount : {{ this.item_discount }}%</v-row>
        <v-row justify="center">Category : {{ this.item_category }}</v-row>
        <v-row justify="center">
          <v-btn class="bg-blue-lighten-3 ma-2" @click="this.qna_dialog = true"> Ask A Question </v-btn>
          <v-btn class="bg-red-lighten-3 ma-2" @click="this.review_dialog = true">Write A Review!</v-btn>

        </v-row>
        <v-row v-for="review in this.item_reviews">
          <v-card elevation="2" class="ma-2 ">
            <template v-slot:title>
              <div class="bg-red-lighten-3 pa-2" style="border-radius: 3px;">Reviewed by : {{ review['USER_NAME'] }}</div>
            </template>
            <template v-slot:subtitle>
              Reviewed on : {{ review['REVIEW_DATE'] }}
            </template>
            <template v-slot:text>
              {{ review['REVIEW'] }}
            </template>
          </v-card>
        </v-row>



        <v-row v-for="qna in this.item_qna">
          <v-card elevation="2" class="ma-2 ">
            <template v-slot:title>
              <div class="bg-blue-lighten-3 pa-2">Asked by: {{ qna['USER_NAME'] }}</div>
              on {{ qna['QUESTION_DATE'] }}
            </template>
            <template v-slot:subtitle>
              Question : {{ qna['QUESTION'] }}
            </template>
            <template v-slot:text>
              Answer : {{ qna['ANSWER'] }}
            </template>
          </v-card>
        </v-row>



      </v-col>
    </v-row>



  </v-container>
</template>

<style></style>